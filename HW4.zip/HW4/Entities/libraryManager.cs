﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.Entities
{
    internal class libraryManager : Person
    {
        public int PersonalId { get; set; }
        public int HoursOfWork { get; set; }

    }
}
