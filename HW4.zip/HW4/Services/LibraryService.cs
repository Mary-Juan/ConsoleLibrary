﻿using HW4.Entities;
using HW4.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.Services
{
    internal  class LibraryService : ILibraryService
    {

        Utility utility = new Utility();

        public bool BorrowBook(int bookId, long userId)
        {
            try
            {
                Member member = utility.GetMemberById(userId);
                Book book = utility.GetBookById(bookId);

                if (member != null && book != null)
                {
                    Database.Database.UnborrowedBooks = Database.Database.UnborrowedBooks.Where(b => b != book).ToArray();
                    member.BorrowedBook = member.BorrowedBook.Append(book).ToArray();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

       

        public Book[] GetListOfLibraryBooks()
        {
            return Database.Database.UnborrowedBooks;
        }

        public Book[] GetListOfUserBooks(long id)
        {
            Member member = utility.GetMemberById(id);
            return member.BorrowedBook;
        }

        public bool ReturnBook(int bookId, long userId)
        {
            try
            {
                Member member = utility.GetMemberById(userId);
                Book book = utility.GetBookById(bookId);

                if (member != null && book != null)
                {
                    Database.Database.UnborrowedBooks = Database.Database.UnborrowedBooks.Append(book).ToArray();
                    member.BorrowedBook = member.BorrowedBook.Where(b => b != book).ToArray();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
