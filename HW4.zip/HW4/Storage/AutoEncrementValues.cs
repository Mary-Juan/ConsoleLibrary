﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.storage
{
    internal static class AutoEncrementValues
    {
        public static int PersonalId = 1;
    }
}
