﻿using HW4.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW4.Database
{
    internal static class Database
    {
        public static Person[] Members = new Person[0];
        public static Person[] LibraryManagers = new Person[0];
        public static Book[] AllBooks = new Book[0];
        public static Book[] UnborrowedBooks = new Book[0];
    }
}
