﻿using HW4.DTOs;
using HW4.Forms;
using HW4.Services;
using HW4.Services.Interfaces;

IAuthentication authentication = new Authentication();
Utility utility = new Utility();
UserMenu userMenu = new UserMenu();

while (true)
{ 
    Console.WriteLine("Welcome to library. eneter '1' to login | enter '2' to register");
string loginOrRegister = Console.ReadLine();

    switch (loginOrRegister)
    {
        case "1":
            {
                LoginDTO login = AuthenticationForms.LoginForm();
                if (authentication.Login(login))
                {
                    Console.WriteLine("----------welcome--------");
                    long memberId = utility.GetIdByEmail(login.Email);
                    while (userMenu.MemberMenu(memberId))
                    {

                    }

                }
                else
                    Console.WriteLine("Not Found");
                break;
            }
        case "2":
            {
                RegisterDTO register = AuthenticationForms.RegisterForm();
               if(register.Role == 0)
                {
                    if (authentication.RegisterEmployee(register))
                    {
                        Console.WriteLine("please login");
                    }
                }
               else if(register.Role == 1)
                {
                    if (authentication.RegisterMember(register))
                    {
                        Console.WriteLine("please login");
                    }
                }

                break;
            }
        default: { break; }
    }

}